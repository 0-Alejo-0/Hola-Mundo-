/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package claseprincipal;

/**
 *
 * @author FREDY ALEJANDRO MATTA CUELLAR - CORPORACION UNIVERSITARIA REPUBLICANA - INGENIERIA DE SISTEMAS
 */
public class Persona {
    //Creamos las variables que ocupemos para crear el programa
    String Nombre, Apellido, Correo, Identificacion, Celular;
    
    
    //Generamos un constructor de todas las variables
    public Persona(String Nombre, String Apellido, String Correo, String identificacion, String celular) {
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Correo = Correo;
        this.Identificacion = identificacion;
        this.Celular = celular;
        
    }

    //Creamos los metodos "GET" y "SET" con nuestras variables 

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }

    public String getIdentificacion() {
        return Identificacion;
    }

    public void setIdentificacion(String Identificacion) {
        this.Identificacion = Identificacion;
    }

    public String getCelular() {
        return Celular;
    }

    public void setCelular(String Celular) {
        this.Celular = Celular;
    }
    
    
    
    
}
