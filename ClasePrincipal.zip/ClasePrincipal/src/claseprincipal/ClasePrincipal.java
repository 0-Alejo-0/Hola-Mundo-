/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package claseprincipal;

/**
 *
 * @author FREDY ALEJANDRO MATTA CUELLAR - CORPORACION UNIVERSITARIA REPUBLICANA - INGENIERIA DE SISTEMAS
 */

public class ClasePrincipal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Concedemos el permiso de que esta clase princiapl pueda hacer visible nuestro JFRAME (interfaz)
        Interfaz interfaz=new Interfaz();
        interfaz.setVisible(true);
    }
    
}
