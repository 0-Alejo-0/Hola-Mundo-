/*
Este proyeto es creado por Fredy Alejandro Matta Cuellar and Ever Julian Obando Rozo,
estudiantes de Ingernieria de Sistemas de la Corporacion Unviersitaria Republicana 4° Semestre
*/
package proyecto.programacion;

import java.awt.Component;
import javax.swing.JOptionPane;

/**
 *
 * @author sebas
 */
public class ProyectoProgramacion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
 
        JOptionPane.showMessageDialog(null, "Hola Mundo Cruel :v Equisdededede");
        
        }
        
         
    }
    
    
    

