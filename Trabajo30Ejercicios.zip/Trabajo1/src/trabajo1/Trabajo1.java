/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabajo1;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Usuario
 */
public class Trabajo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int estado, uno, dos, tres, repetir, repetir1, repetir2, repetir3;
        
        do{
        estado = Integer.parseInt(JOptionPane.showInputDialog("Menu:\n0.Para salir\n1.Ejercicios 1 - 10"
                + "\n2.Ejercicios 11 - 20"
                + "\n3.Ejercicios 21 - 30"));
        repetir = 0;
        
        switch(estado){
            case 1: 
                uno = Integer.parseInt(JOptionPane.showInputDialog(null, "Ejercicios:\n0.Para volver\n1.Numero Primo"
                        + "\n2.Caracter en una cadena\n3.Cadena hay solo digitos\n4.N posiciones en orden ascendente"
                        + "\n5.Los primero n numeros primos\n6.Numero narcisista\n7.Palabra palindromo"
                        + "\n8.Invertir cadena de caracteres\n9.Obetern subcade de una cadena\n10.Elemento mayor en un arreglo"));
                repetir1 = 0;
                switch(uno){
                    case 1:
                        Punto1(); 
                        break;
                    case 2:
                        Punto2();
                        break; 
                    case 3:
                        Punto3();
                        break;
                    case 4:
                        Punto4();
                        break;
                    case 5:
                        Punto5();
                        break;
                    case 6:
                        Punto6();
                        break;
                    case 7:
                        Punto7();
                        break;
                    case 8:
                        Punto8();
                        break;
                    case 9:
                        Punto9();
                        break;
                    case 10:
                        Punto10();
                        break;  
                    case 0:
                        repetir = 1;
                        break;    
                }
                break; 
                
            case 2:
                dos = Integer.parseInt(JOptionPane.showInputDialog(null, "Ejercicios:\n0.Para volver\n11.Elemento mayor en un arreglo"
                        + "\n12.Elemento menor en un arreglo\n13.Caracteres de una cadena son letras mayusculas\n14.Ller cadena de acuerdo a una mascarila"
                        + "\n15.Promdeio de n numeros agrupados\n16.Cociente de una division usando restas\n17.Productos de dos numeros usando sumas sucesivas"
                        + "\n18.Raiz aproximada de un numero naural\n19.Comparar dos cadenas dadas con verdadero y falso\n20.Primeros 5 numeros narcisistas"));
                repetir2 = 0;
                switch(dos){
                    case 11:
                        Punto11(); 
                        break;
                    case 12:
                        Punto12();
                        break; 
                    case 13:
                        Punto13();
                        break;
                    case 14:
                        Punto14();
                        break;
                    case 15:
                        Punto15();
                        break;
                    case 16:
                        Punto16();
                        break;
                    case 17:
                        Punto17();
                        break;
                    case 18:
                        Punto18();
                        break;
                    case 19:
                        Punto19();
                        break;
                    case 20:
                        Punto20();
                        break;  
                    case 0:
                        repetir = 1;
                        break;
                }
                break;
            case  3:
                tres = Integer.parseInt(JOptionPane.showInputDialog(null, "Ejercicios:\n0.Para volver\n21.Retornar numero n eleveado a la potencia m"
                        + "\n22.Piramide de bolas\n23.Funcion que determine si n es multiplo de m\n24.Funcion para determinar si un numero dado es perfecto"
                        + "\n25.El mayo, el menor y el promedio de n numeros\n26.Retorno del ultimo digito de un entero dado\n27.Retorno invertido de un numero entero dado "
                        + "\n28.LLenado de arreglo bidimensional, con numero incial\n29.Llenado de un arreglo bidimensional con unos y ceros\n30.Determinar cuantos 0 y 1 hay enalrededor de la posicion 2,2"));
                repetir3 = 0;
                switch(tres){
                    case 21:
                        Punto21();  
                        break;
                    case 22:
                        Punto22();
                        break; 
                    case 23:
                        Punto23();
                        break;
                    case 24:
                        Punto24();
                        break;
                    case 25:
                        Punto25();
                        break;
                    case 26:
                        Punto26();
                        break;
                    case 27:
                        Punto27();
                        break;
                    case 28:
                        Punto28();
                        break;
                    case 29:
                        Punto29();
                        break;
                    case 30:
                        Punto30();
                        break;  
                    case 0:
                        repetir = 1;
                        break;
                }
                break;
            case 0:
                System.exit(0);    
                break;
        
    }}while(estado!=4);
    }
    
 public static void Punto1(){ 
     
     String cadena;
     int numero, num2;
     cadena=JOptionPane.showInputDialog(null, "Ingrese un numero entero.");
     numero=Integer.parseInt(cadena);
     num2 = numero - 1;
     while ((numero%num2)!= 0){
         num2 --;
     } if (num2 == 1){
         JOptionPane.showMessageDialog(null, "El numero ingresado es primo ");
     } else {
         JOptionPane.showMessageDialog(null, "El numero ingresado no es primo ");
     }
}
 
    public static void Punto2() {

        String usuario = JOptionPane.showInputDialog("Ingrese una cadena ejem: nombre");
        String caracter = JOptionPane.showInputDialog("Ingrese el caracter a buscar");
        char[] vector = usuario.toCharArray();
        for (int i = 0; i < usuario.length(); i++) {
            String letra = String.valueOf(vector[i]);
            if (caracter.equalsIgnoreCase(letra)) {
                JOptionPane.showMessageDialog(null, "La letra:(" + caracter + ") ..se encuentra en la posicion: " + (i + 1));
            }
        }
    }
 
 public static void Punto3(){    
     
     String cadena = JOptionPane.showInputDialog("Ingrese una cadena con letras y numeros");
            ArrayList<Character> lista = new ArrayList<>();
            for(int i = 0; i< cadena.length(); i ++)
            {
                if(Character.isDigit(cadena.charAt(i)))
                    lista.add(cadena.charAt(i));

            }
            for(int j = 0; j< lista.size();j ++)
            {
                JOptionPane.showMessageDialog(null,"numero: "+(lista.get(j)));              
            }
}
 
 public static void Punto4(){    
     
     Scanner scanner = new Scanner(System.in);
     int arreglo[], Numeros, ordenar;
     
     Numeros = Integer.parseInt(JOptionPane.showInputDialog("Digite la canitdad de numeros que desea ordenar"));
     arreglo = new int [Numeros];
     
     for (int i=0; i<Numeros; i++){
         System.out.print((i+1)+". Digite el numero: ");
         arreglo[i]= scanner.nextInt();
    }
     //Metodo burbuja para ordenar
     for (int i = 0; i < (Numeros-1); i++) {
         for (int j = 0; j < (Numeros-1); j++) {
             if (arreglo[j]>arreglo[j+1]) {
                  ordenar = arreglo[j];
                  arreglo[j] = arreglo[j+1];
                  arreglo[j+1]= ordenar;                 
             }
             
         }
         
     }
     //Mostrar resultado
     System.out.println("\nArreglo ordenado en forma ascendente: ");
     for (int i = 0; i < Numeros; i++) {
         System.out.print(arreglo[i]+" - ");
     }
  
}
 
 public static void Punto5(){   
     
     int numero = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero"));
     System.out.println("1");
     for (int i = 1; i < numero; i++) {
         int contador = 0;
         for (int j = 1; j <= i ; j++) {
             if (i % j==0) 
                 contador++;
         }
        if (contador==2) {
             System.out.println(i);
         }
     }
}
 
 public static void Punto6(){    
     
    int resultado=0,digitos,temp;  
    int numero = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero"));
    temp=numero;  
    while(numero>0)  
    {  
    digitos=numero%10;  
    numero=numero/10;  
    resultado=resultado+(digitos*digitos*digitos);  
    }  
    if(temp==resultado){
    JOptionPane.showMessageDialog(null,"El numero ingresado si es narcisista");   
    }else  
        JOptionPane.showMessageDialog(null,"El numero ingresado no es narcisista ");   
   }  
 
 public static void Punto7(){   
     
   String palabra = JOptionPane.showInputDialog(null,"Escriba la palabra: ");
   int contador = 1;
     for (int i = 0; i < palabra.length(); i++) {
         if (palabra.charAt(i)!= palabra.charAt(palabra.length()-1-i)) {
             contador = 0;
             break;
         }
     }
     System.out.println(contador ==1 ? "La palabra es palindromo":"La palabra no es palindromo");
}
 
 public static void Punto8(){    
     
        
        String palabra  = JOptionPane.showInputDialog(null,"Escriba la palabra: ");
        String invertida="";
 
        for (int i = palabra.length()-1; i>=0; i--){
            invertida += palabra.charAt(i);
        }
 
       JOptionPane.showMessageDialog(null,"La palabra es:  "+palabra+ "\nLa palabra invertida es:  "+invertida);
}
 
 public static void Punto9(){  
     
     int num_a, num_b;
     String numero1, numero2;
     String Cadena = JOptionPane.showInputDialog("Ingresa la cadena");
     numero1 = JOptionPane.showInputDialog("Ingrese la posicion por la cual comenzar la subcadena");
     num_a = Integer.parseInt(numero1);
     numero2 = JOptionPane.showInputDialog("Ingrese la posicion por la cual termina la subcadena");
     num_b = Integer.parseInt(numero2);
     String subcadena = Cadena.substring(num_a,num_b);
     JOptionPane.showMessageDialog(null,"La palabra invertida es:  "+subcadena);
}
 
 public static void Punto10(){  
     
        Scanner teclado = new Scanner(System.in);
        int n;
        String numero;
        numero = JOptionPane.showInputDialog("Por favor ingrese la cantidad de numeros a comparar: ");
        n = Integer.parseInt(numero);
        int array [] = new int [n];
       
        for (int i = 0; i < array.length; i++) {
            System.out.print("Ingrese el numero "+(i+1)+": ");
            array [i] = teclado.nextInt();
        }
       
        int mayor;
        mayor = array [0];
       
        for (int i = 0; i < array.length; i++) {
            if(array [i] > mayor) {
                mayor = array[i];
            }
        }
        JOptionPane.showMessageDialog(null,"El numero mayor es: "+mayor);
}
 
 public static void Punto11(){   
     
     Scanner teclado = new Scanner(System.in);
        
        String numero;
        numero = JOptionPane.showInputDialog("Por favor ingrese la cantidad de numeros a comparar: ");
        int n = Integer.parseInt(numero);
        int array [] = new int [n];
       
        for (int i = 0; i < array.length; i++) {
            System.out.print("Ingrese el numero "+(i+1)+": ");
            array [i] = teclado.nextInt();
        }
       
        int menor;
        menor = array [0];
       
        for (int i = 0; i < array.length; i++) {
            if(array [i] < menor) {
                menor = array[i];
            }
        }
        JOptionPane.showMessageDialog(null,"El numero menor es: "+menor);
}
 
 public static void Punto12(){    
     
     Scanner lector = new Scanner(System.in);   
     String numero;
     int numeros;
     
        numero = JOptionPane.showInputDialog("Por favor ingrese la cantidad de numeros a comparar: ");
        int n = Integer.parseInt(numero);
        int array [] = new int [n];
        
        for (int i = 0; i < n; i++) {
            numeros = Integer.parseInt(JOptionPane.showInputDialog(". Digite "+(i+1)+" numero: "));
            array [i]=numeros; 
        }
        int menor, mayor;
        menor=mayor=array[0];
        for (int j = 0; j < n; j++) {
            if (array[j]>mayor) {
                mayor=array[j];
            }if (array[j]<menor) {
                menor=array[j];
            }
        } 
     JOptionPane.showMessageDialog(null,"El numero mayor es: "+mayor);
     JOptionPane.showMessageDialog(null,"El numero menor es: "+menor);
     JOptionPane.showMessageDialog(null,"El rango de numeros ingresados es de: "+menor+" hasta: "+mayor);
}
 
 public static void Punto13(){    
     
}
 
 public static void Punto14(){   
     
     
     
}
 
 public static void Punto15(){    
     
     int cantidad, num=0, numeros;
     float promedio;
     
     cantidad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de numeros"));
     for (int i = 0; i < cantidad; i++) {
         numeros = Integer.parseInt(JOptionPane.showInputDialog("Digite un numero"));
         num += numeros;
     }
     promedio = (float) num/cantidad;
     JOptionPane.showMessageDialog(null,"El promedio de los numeros es: "+ promedio);
     
}
 
 public static void Punto16(){ 
     
     int cociente =0, divisor, dividendo;
     dividendo = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el dividendo"));
     divisor = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el divisor"));
     
     cociente = dividendo - divisor;
     
     while  (dividendo>=0){
         cociente = cociente +1;
         dividendo = dividendo-divisor;
     }
    JOptionPane.showMessageDialog(null,"El cociente de la division es: "+cociente);   
}
 
 public static void Punto17(){   
    
     int producto =0, a, b;
     b = Integer.parseInt(JOptionPane.showInputDialog("Ingrese primer numero"));
     a = Integer.parseInt(JOptionPane.showInputDialog("Ingrese segundo numero"));

     while  (b!=0){
         producto = producto +a;
         b = b-1;
     }
    JOptionPane.showMessageDialog(null,"El producto de la division es: "+producto);   
}
 
 public static void Punto18(){  
     
     int numero;
     numero = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el radicando: "));
     float resultado1 = (float) Math.sqrt(numero);
     JOptionPane.showMessageDialog(null,"La raiz cuadrada de " + numero +  " es: " + resultado1);
}
 
 public static void Punto19(){ 
     
    String PrimeraCadena = JOptionPane.showInputDialog("Ingresa la primera cadena");
    String SegundaCadena = JOptionPane.showInputDialog("Ingresa la segunda cadena");

    if(PrimeraCadena.equals(SegundaCadena)){
      JOptionPane.showMessageDialog(null,"Las cadenas son iguales");
    }else{
      JOptionPane.showMessageDialog(null,"Las cadenas no son iguales");
    }
}
 
 public static void Punto20(){  
     
     int n = 6;
     for(int i=0;i<=n;i++){
            String j = Integer.toString(i);
            int p = j.length();
            int s = 0;
            for(int k=0;k<p;k++){
                char ch = j.charAt(k);
                int d = Character.getNumericValue(ch);
                s += Math.pow(d,p);
            }
            if(s==i){
                JOptionPane.showMessageDialog(null,"Los 5 primeros narcisistas son: "+s);
            }
        }
     
}
 
 public static void Punto21(){ 
     
     int resultado=1, n, m;
     n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese numero"));
     m = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la potencia del numero"));

     for (int i = 1; i <= m; i++) {
         resultado = resultado * n;        
     } 
    JOptionPane.showMessageDialog(null,"El resultado es: "+resultado);   
}
 
 public static void Punto22(){   
     //////No lo logre 
}
 
 public static void Punto23(){    
     
     int num1, num2, resultado;
     num1 = Integer.parseInt(JOptionPane.showInputDialog("Ingrese primer numero"));
     num2 = Integer.parseInt(JOptionPane.showInputDialog("Ingrese segundo numero"));
     
     resultado =num1%num2;
     if (resultado==0) {
         JOptionPane.showMessageDialog(null,"El numero: "+num2+" si es multiplo de: "+num1);
     }else{
         JOptionPane.showMessageDialog(null,"El numero: "+num2+" no es multiplo de: "+num1);
     }
}
 
 public static void Punto24(){ 
     
     int numero, suma=0;
     numero = Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero"));
     for (int i = 1; i < numero; i++) {
         if (numero%i==0){
             suma = suma+i;    
         }
     }if (suma==numero) {
             JOptionPane.showMessageDialog(null,"El numero ingresado es perfecto");
         }else
             JOptionPane.showMessageDialog(null,"El numero ingresado no es perfecto");
}
 
 public static void Punto25(){   
     
     Scanner lector = new Scanner(System.in);   
     String numero;
     int numeros, total=0, promedio;
     
        numero = JOptionPane.showInputDialog("Por favor ingrese la cantidad de numeros: ");
        int n = Integer.parseInt(numero);
        int array [] = new int [n];
        
        for (int i = 0; i < n; i++) {
            numeros = Integer.parseInt(JOptionPane.showInputDialog("Digite "+(i+1)+" numero: "));
            array [i]=numeros; 
        }
        int menor, mayor;
        menor=mayor=array[0];
        for (int j = 0; j < n; j++) {
            if (array[j]>mayor) {
                mayor=array[j];
            }if (array[j]<menor) {
                menor=array[j];
            }
        }
        for (int i = 0; i < array.length; i++) {
            total = total + array[i];
        }
         promedio = total/n;
     JOptionPane.showMessageDialog(null,"El numero mayor es: "+mayor);
     JOptionPane.showMessageDialog(null,"El numero menor es: "+menor);
     JOptionPane.showMessageDialog(null,"El promedio en la suma de los numeros es: "+promedio);
}
 
 public static void Punto26(){   
     
     int numero;
     numero = Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero")); 
     
     int UltimoDigito = numero%10;
     JOptionPane.showMessageDialog(null,"El último dígito de " +numero+ " es " + UltimoDigito);
     
}
 
 public static void Punto27(){   
     
     int numero, NumInvertido = 0, operacion;
     numero = Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero"));
     
     while(numero>0){
         operacion= numero%10;
         NumInvertido = NumInvertido *10+(operacion);
         numero/=10;
     }
 JOptionPane.showMessageDialog(null,"El numero al ser invertido es: " +NumInvertido);    
}
 
 public static void Punto28(){   
     
     
     int numeroinicial;
     numeroinicial = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero inicial"));
     int matriz [][] = new int[3][3];
        matriz[0][0]=numeroinicial;
        Random numAleatorio;
        numAleatorio = new Random ();
        matriz[0][1] = numAleatorio.nextInt(100);   
        matriz[0][2] = numAleatorio.nextInt(100);   
        matriz[1][0] = numAleatorio.nextInt(100);   
        matriz[1][1] = numAleatorio.nextInt(100);   
        matriz[1][2] = numAleatorio.nextInt(100);   
        matriz[2][0] = numAleatorio.nextInt(100);   
        matriz[2][1] = numAleatorio.nextInt(100);   
        matriz[2][2] = numAleatorio.nextInt(100);   
        
        for (int k=0;k<matriz.length;k++){
            for (int f=0;f<matriz.length;f++){
                System.out.print(matriz[k][f]+" ");
            }
            System.out.println("");
        }
     
}
 
 public static void Punto29(){ 
     
     int matriz [][] = new int[3][3];
        
        Random numAleatorio;
        numAleatorio = new Random ();
        matriz[0][0] = numAleatorio.nextInt(2);   
        matriz[0][1] = numAleatorio.nextInt(2);   
        matriz[0][2] = numAleatorio.nextInt(2);   
        matriz[1][0] = numAleatorio.nextInt(2);   
        matriz[1][1] = numAleatorio.nextInt(2);   
        matriz[1][2] = numAleatorio.nextInt(2);   
        matriz[2][0] = numAleatorio.nextInt(2);   
        matriz[2][1] = numAleatorio.nextInt(2);   
        matriz[2][2] = numAleatorio.nextInt(2);   
        
        for (int k=0;k<matriz.length;k++){
            for (int f=0;f<matriz.length;f++){
                System.out.print(matriz[k][f]+" ");
            }
            System.out.println();
        }
     
     
}
 
 public static void Punto30(){    
}
 
}

